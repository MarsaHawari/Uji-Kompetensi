package com.marsa.autocare2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

public class DetailJasaActivity extends AppCompatActivity {
    TextView namaservicedetail, deskripsiservicedetail, hargaservicedetail;
    ImageView gambar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_jasa);

        Intent i = getIntent();

        load();
        namaservicedetail.setText(getIntent().getStringExtra("namaservice"));
        deskripsiservicedetail.setText(getIntent().getStringExtra("detailjasaservice"));
        hargaservicedetail.setText(getIntent().getStringExtra("hargaservice"));
        Glide.with(DetailJasaActivity.this)
                .load(""+ i.getStringExtra("gambar"))
                .into(gambar);
    }

    public void load(){
        namaservicedetail = findViewById(R.id.namaservicedetail);
        deskripsiservicedetail = findViewById(R.id.deskripsiservicedetail);
        hargaservicedetail = findViewById(R.id.hargaservicedetail);
        gambar = findViewById(R.id.gambardetail);




    }




    public void btnSewaJasa(View view) {
            Intent intent = new Intent(this, ChekoutActivity.class);
            intent.putExtra("namaservice",getIntent().getStringExtra("namaservice"));
            intent.putExtra("hargaservice",getIntent().getStringExtra("hargaservice"));

            startActivity(intent);
    }

    public void btnBackHome(View view) {
        Intent intent = new Intent(this, Home.class);
        startActivity(intent);
    }
}