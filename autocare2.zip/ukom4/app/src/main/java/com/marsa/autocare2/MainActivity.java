package com.marsa.autocare2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.marsa.autocare2.Login.LoginRequest;
import com.marsa.autocare2.Login.LoginResponse;
import com.marsa.autocare2.ServicePackage.JasaService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    EditText logusername,logpassword;
    Button btnlogin;
    JasaService jasaService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logusername = findViewById(R.id.logusername);
        logpassword = findViewById(R.id.logpassword);
        btnlogin = findViewById(R.id.btnLogin);
        jasaService = Api.getService().create(JasaService.class);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if (TextUtils.isEmpty(logusername.getText().toString())){
                logusername.setError("Username is required");
                logusername.requestFocus();
            }else if (TextUtils.isEmpty(logpassword.getText().toString())){
                logpassword.setError("Password is required");
                logpassword.requestFocus();
            }else {
                login() ;
            }
            }
        });
    }

    public void login(){
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername(logusername.getText().toString());
        loginRequest.setPassword(logpassword.getText().toString());
        Call<LoginResponse> call = jasaService.loginuser(loginRequest);
        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.body()==null){
                    Toast.makeText(MainActivity.this, "Username/password salah", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, WaitActivity.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Username/password salah", Toast.LENGTH_SHORT).show();
                Log.e("Retrofit", t.toString());
            }
        });
    }

//    public void btnLogin(View view) {
//        Intent intent = new Intent(this,Home.class );
//        startActivity(intent);
//    }

    public void btnRegistrasi(View view) {
        Intent intent = new Intent(this,Register.class);
        startActivity(intent);
    }

    public void Lupapassword(View view) {
        Intent intent = new Intent(this,LupaPassword.class);
        startActivity(intent);
    }



}