package com.marsa.autocare2.ServicePackage;

import com.marsa.autocare2.Login.LoginRequest;
import com.marsa.autocare2.Login.LoginResponse;
import com.marsa.autocare2.Model.ModelAutocare;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface JasaService {

    @GET("api/service")
    Call<List<ModelAutocare>> getData();

    @POST("api/service")
    Call<ModelAutocare> setData(@Body ModelAutocare service);

    @DELETE("api/service/{id}")
    Call<ModelAutocare>  deleteData(@Path("id") String id);

    @POST ("api/loginpelanggan")
    Call<LoginResponse> loginuser(@Body LoginRequest loginRequest);


}
