package com.marsa.autocare2.Model;

public class ModelAutocare {
    private String namaservice;
    private String deskripsiservice;
    private String harga;
    private String imgservice;

    public String getNamaservice() {
        return namaservice;
    }

    public String getDeskripsiservice() {
        return deskripsiservice;
    }

    public String getHarga() {
        return harga;
    }

    public String getgambar(){return imgservice;}
}
