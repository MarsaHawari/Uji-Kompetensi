package com.marsa.autocare2;

public class Jasa {
    private String namaJasa;
    private String detailJasa;
    private String hargaJasa;

    public Jasa(String namaJasa, String detailJasa, String hargaJasa) {
        this.namaJasa = namaJasa;
        this.detailJasa = detailJasa;
        this.hargaJasa = hargaJasa;
    }

    public String getNamaJasa() {
        return namaJasa;
    }

    public void setNamaJasa(String namaJasa) {
        this.namaJasa = namaJasa;
    }

    public String getDetailJasa() {
        return detailJasa;
    }

    public void setDetailJasa(String detailJasa) {
        this.detailJasa = detailJasa;
    }

    public String getHargaJasa() {
        return hargaJasa;
    }

    public void setHargaJasa(String hargaJasa) {
        this.hargaJasa = hargaJasa;
    }
}
