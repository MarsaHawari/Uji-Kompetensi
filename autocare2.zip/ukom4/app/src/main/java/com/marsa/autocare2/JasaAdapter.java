package com.marsa.autocare2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class JasaAdapter extends RecyclerView.Adapter<JasaAdapter.ViewHolder> {

    private Context context;
    private List<Jasa> jasaList;

    public JasaAdapter(Context context, List<Jasa> jasaList) {
        this.context = context;
        this.jasaList = jasaList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list,viewGroup,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Jasa jasa = jasaList.get(i);
        viewHolder.namaJasa.setText(jasa.getNamaJasa());
        viewHolder.detailJasa.setText(jasa.getDetailJasa());
        viewHolder.hargaJasa.setText(jasa.getHargaJasa());
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailJasaActivity.class);
                context.startActivity(intent);
            }
        });



    }

    @Override
    public int getItemCount() {
        return jasaList.size();
    }




    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView namaJasa,detailJasa,hargaJasa;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            namaJasa = itemView.findViewById(R.id.namaJasa);
            detailJasa = itemView.findViewById(R.id.detailJasa);
            hargaJasa = itemView.findViewById(R.id.hargaJasa);
        }
    }
}
