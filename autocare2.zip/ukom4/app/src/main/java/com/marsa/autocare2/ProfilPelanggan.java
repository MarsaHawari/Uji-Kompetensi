package com.marsa.autocare2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ProfilPelanggan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_pelanggan);
    }

    public void btnSimpanProfil(View view) {
        Intent intent = new Intent(this, Home.class);
        startActivity(intent);
    }

    public void btnAkunKeluar(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }




}