package com.marsa.autocare2;

import androidx.appcompat.app.AppCompatActivity;
import in.aabhasjindal.otptextview.OTPListener;
import in.aabhasjindal.otptextview.OtpTextView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class LupaPassword extends AppCompatActivity {

    private OtpTextView otpTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lupa_password);

        otpTextView = findViewById(R.id.otpview);
        otpTextView.setOtpListener(new OTPListener() {
            @Override
            public void onInteractionListener() {

            }

            @Override
            public void onOTPComplete(String otp) {
                if (otp.equals("12345")){
                    otpTextView.showSuccess();
                Toast.makeText(LupaPassword.this, "Kode Verifikasi BEnar"+ otp, Toast.LENGTH_LONG).show();
            }else {
                    otpTextView.showError();
                    Toast.makeText(LupaPassword.this, "Kode Verifikasi salah"+ otp, Toast.LENGTH_LONG).show();

                }
            }
        });
    }

    public void btnselesai(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


    public void btnRegistrasi(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}