package com.marsa.autocare2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

//import com.google.android.gms.safetynet.SafetyNet;

public class Register extends AppCompatActivity {

    EditText pw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        pw = findViewById(R.id.PasswordPelanggan);

        if (pw.getText().toString().length()<=8){
            pw.setError("KURANG DARI 8");
        }

    }

    public void tvRegister(View view) {
        Intent intent = new Intent(this,MainActivity.class );
        startActivity(intent);
    }

    public void btnRegistrasiSelesai(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


    }


