package com.marsa.autocare2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.marsa.autocare2.Adapter.AdapterService;
import com.marsa.autocare2.Model.ModelAutocare;
//import com.marsa.autocare2.Rest.ApiClient;
import com.marsa.autocare2.ServicePackage.JasaService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Home extends AppCompatActivity {
    RecyclerView recyclerView;
    JasaAdapter adapter;
    List<Jasa> jasaList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        refresh();

//        load();
//        isiData();
    }

    public  void refresh(){
        RecyclerView rcvHome = findViewById(R.id.rcvHome);
        rcvHome.setLayoutManager(new GridLayoutManager(this,2));
        rcvHome.setHasFixedSize(true);
        JasaService service = Api.getService().create(JasaService.class);
        Call<List<ModelAutocare>> call = service.getData();
        call.enqueue(new Callback<List<ModelAutocare>>() {
            @Override
            public void onResponse(Call<List<ModelAutocare>> call, Response<List<ModelAutocare>> response) {
                List<ModelAutocare> data = response.body();
                rcvHome.setAdapter(new AdapterService(Home.this,data));
            }

            @Override
            public void onFailure(Call<List<ModelAutocare>> call, Throwable t) {
                Toast.makeText(Home.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }

//    public void load(){
//        recyclerView = findViewById(R.id.rcvHome);
//        recyclerView.setLayoutManager(new GridLayoutManager(this,2));
//    }

//    public void isiData(){
//          jasaList = new ArrayList<Jasa>();
//          jasaList.add(new Jasa("Servis Besar", "Ini Servis Besar", "5000"));
//          jasaList.add(new Jasa("Servis Besar", "Ini Servis Besar", "5000"));
//          jasaList.add(new Jasa("Servis Besar", "Ini Servis Besar", "5000"));
//          jasaList.add(new Jasa("Servis Besar", "Ini Servis Besar", "5000"));
//          adapter = new JasaAdapter(this,jasaList);
//          recyclerView.setAdapter(adapter);
//    }



    public void btnEditProfil(View view) {
        Intent intent = new Intent(this, ProfilPelanggan.class);
        startActivity(intent);
    }

}



