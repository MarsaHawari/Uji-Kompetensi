package com.marsa.autocare2.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.marsa.autocare2.DetailJasaActivity;
import com.marsa.autocare2.Model.ModelAutocare;
import com.marsa.autocare2.R;

import java.util.List;

public class AdapterService extends RecyclerView.Adapter<AdapterService.ViewHolder> {

    Context context;
    List<ModelAutocare> data;


    public AdapterService(Context context, List<ModelAutocare> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ModelAutocare service = data.get(position);
        holder.namaJasa.setText(service.getNamaservice());
        holder.detailJasa.setText(service.getDeskripsiservice());
        holder.hargaJasa.setText(service.getHarga());
        Glide.with(holder.itemView.getContext())
                .load(""+service.getgambar())
                .into(holder.gambar);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailJasaActivity.class);
                intent.putExtra("namaservice", service.getNamaservice() );
                intent.putExtra("detailjasaservice", service.getDeskripsiservice());
                intent.putExtra("hargaservice",service.getHarga());
                intent.putExtra("gambar",service.getgambar());
                context.startActivity(intent);


            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView gambar;
        TextView namaJasa,detailJasa,hargaJasa;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            namaJasa = itemView.findViewById(R.id.namaJasa);
            detailJasa = itemView.findViewById(R.id.detailJasa);
            hargaJasa = itemView.findViewById(R.id.hargaJasa);
            gambar = itemView.findViewById(R.id.gambarJasa);
        }
    }
}
