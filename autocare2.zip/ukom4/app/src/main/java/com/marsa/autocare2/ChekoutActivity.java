package com.marsa.autocare2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ChekoutActivity extends AppCompatActivity {

    TextView namajasacheckout, hargaJasacheckout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chekout);

        load();
        namajasacheckout.setText(getIntent().getStringExtra("namaservice"));
        hargaJasacheckout.setText(getIntent().getStringExtra("hargaservice"));
    }

    public void load(){
        namajasacheckout = findViewById(R.id.namajasacheckout);
        hargaJasacheckout = findViewById(R.id.hargaJasacheckout);}








    public void btnLetsGo(View view) {
        Intent intent = new Intent(this, SudahPunyaAkun.class);
        startActivity(intent);
    }


    public void btnBackDetail(View view) {
//        Intent intent = new Intent(this, DetailJasaActivity.class);
//        startActivity(intent);
        finish();
    }
}